Projektkrav

1. Använda oss av minst 1 API (OpenWeather)
2. Ett ramverk (React)
3. Ska vara responsivt.
4. Använda oss av git med branches och tydliga commits.
5. Spara data lokalt.


Våra krav
1. Hämta väder beroende på input från användare.
2. Presentera vädret på ett snyggt sätt.
3. Spara senaste sökningarna. 
4. Användaren ska kunna spara och ta bort favoriter. (om vi har tid)
5. Ändra utseende beroende på väder. 